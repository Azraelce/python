#判断某人是否是自己组员，yes：欢迎，no：滚
zuyuan="脏衣你好卡"
your_zuyuan=input("请输入:")
if your_zuyuan in zuyuan:
    ture=your_zuyuan
if ture:
    print("欢迎 {}".format(your_zuyuan))
else:
    print("滚")