import pygame
import random
import math
pygame.init()
sc=pygame.display.set_mode((500,700))
bg=pygame.image.load("bg.png")
font=pygame.font.SysFont(" ",60)
gameover=font.render("game over",True,(255,255,255))
MousedownToRestart=font.render("MousedownToRestart",True,(255,255,255))
enemymount=10#敌人数量
enemysite=[]
speed=[]
for i in range(enemymount):#初始化敌人出现的位置
    enemysite.append((random.randint(0,500),0))
for i in range(enemymount):#初始化敌人速度
    speed.append(random.randint(1,10))
breakflag=True
grade=0
time=0
while True:
    if breakflag:
        sc.blit(bg, (0, 0))  # 画背景

        grade = str(grade)
        score = font.render("score:"+grade, True, (255, 255, 255))
        grade = int(grade)
        time=time+1
        if time>20:#画分数
            grade = grade + 1
            time=0
        sc.blit(score, (10, 10))

        for i in range(enemymount):#画敌人
            pygame.draw.circle(sc,(25,32,255),(enemysite[i][0],enemysite[i][1]),6,6)
            enemysite[i]=(enemysite[i][0],enemysite[i][1]+speed[i])#加速
            if enemysite[i][1]>700:
                enemysite[i] = (random.randint(0,500), 0)#出界重置
                speed[i]=random.randint(1,10)

        x,y=pygame.mouse.get_pos()
        pygame.draw.circle(sc, (255, 0, 0), (x,y), 15, 15)

        for i in range(enemymount):#判断碰撞
            xdistance=abs(enemysite[i][0]-x)
            ydistance=abs(enemysite[i][1]-y)
            distance=math.sqrt(abs(xdistance*xdistance+ydistance*ydistance))
            if distance < 12:
                sc.blit(gameover,(130,200))
                sc.blit(MousedownToRestart,(20,270))
                breakflag=False


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            for i in range(enemymount):
                enemysite[i] = (random.randint(0, 500), 0)
            breakflag = True
            time = 0
            grade=0
    pygame.display.update()