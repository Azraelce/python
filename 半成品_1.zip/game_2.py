import pygame
sc=pygame.display.set_mode((500,600))
star=pygame.image.load("1140699.png")
sc.blit(star, (100, 100))
while True:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            exit()
            pygame.display.update()